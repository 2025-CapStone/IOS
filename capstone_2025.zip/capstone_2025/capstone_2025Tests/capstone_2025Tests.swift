//
//  capstone_2025Tests.swift
//  capstone_2025Tests
//
//  Created by Yoon on 2/18/25.
//

import Testing
@testable import capstone_2025

struct capstone_2025Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
