//
//  RefreshTokenResponse.swift
//  capstone_2025
//
//  Created by ㅇㅇ ㅇ on 4/29/25.
//


import Foundation

struct RefreshTokenResponse: Codable {
    let accessToken: String
}
