//import Foundation
//
//struct ClubResponseDTO: Decodable, Identifiable {
//    let clubId: Int
//    let clubName: String
//    let clubDescription: String
//    let clubLogoURL: String?
//    let clubBackgroundURL: String?
//    let clubCreatedAt: String
//
//    var id: Int { clubId }
//}
