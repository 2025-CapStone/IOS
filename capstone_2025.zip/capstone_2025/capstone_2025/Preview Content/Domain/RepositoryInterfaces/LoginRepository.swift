//
//  LoginRepository.swift
//  capstone_2025
//
//  Created by ㅇㅇ ㅇ on 4/5/25.
//

protocol LoginRepository{}
